ProClaw 导入示例包（v1.3 C2）
===================================

目录结构：
  products-template.xlsx             商品导入模板（28 列）
  inventory-template.xlsx            库存交易模板（9 列）
  purchases-template.xlsx            采购订单模板（8 列）
  sales-template.xlsx                销售订单模板（8 列）
  suppliers-customers-template.xlsx  主数据模板（双 sheet）
  images/                            10 张示例图（与 products 模板的 image_filename 字段对应）

使用步骤：
  1. 打开 Step1 文件选择向导 → 选择对应模板填数据
  2. 如导入商品，可同时上传本 zip 作为图片源
  3. 后端 import_extract_images 会自动按 image_filename 字段匹配

图片文件名校约定：
  - 单一图片：  <SPU编码>_main.png
  - 多图：      <SPU编码>_<任意描述>.png
  - SKU 维度：  <SKU编码>_<x>.png
